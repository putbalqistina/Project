# *************************************************************************
# Course: CSP1114 PROBLEM SOLVING AND PROGRAM DESIGN
# Lecture / Lab Section: TC1L / TL4L
# Trimester: 2530
# Group Name (from eBwise): Group 7
# Names: PUTERI BALQIS QISTINA BINTI MD IZAN | AMINAH BINTI MAZLAN | NURDANIA QISTINA BINTI NOOR AZIZUL RAHIM
# IDs: 252FC253ME | 252FC253CF | 252FC253H4
# *************************************************************************

import os
import opening
import level1
import level2
import level3
import level4
import level5
import random

#opening story
opening.starting()

# level 1
level1.level_1()

# level 2
level2.level_2()

# level 3
level3.level_3()

# level 4
level4.level_4()

# level 5
level5.level_5()





