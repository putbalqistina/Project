import os
import random
def level5_opening():
    print()
    print("Level 5: Fifth Floor ִֶָ𓂃 ࣪˖𓉸ִֶָྀི ִֶָ་༘࿐")
    print()
    print('OH NO! There is a big boss in front of you!')
    print('Boss stat= health: 20, attack: 20')
    print("You can create max. 5 potions in order to surpass the big boss' stats.")
    print('If you failed to do so, then... say goodbye to the treasure chest.')

def level5_minigame():
    words = {"wizard": "Because it's you, A Wisdom Potion Maker",
            "witch": "Because it's you, A Wisdom Potion Maker",
            "warrior": "Because it's you, The Fearless Warrior.",
            "achiever": "Because it's you, who achieving their dreams.",
            "fighter": "Because it's you, who fight at all costs.",
            "hero": "Because it's you, A True Champion"}

    def display_hint(hint):
        print(" ".join(hint))

    def display_answer(answer):
        print(" ".join(answer))


    def mini_game():
        answer = random.choice(list(words.keys()))
        clue = words[answer]
        hint = ["_"] * len(answer)
        guessed_letters = set()
        is_running = True
        tries = 6


        while is_running:
            display_hint(hint)
            print(f"Hint: {clue}")
            print(f"Tries left; {tries}")
            guess = input("Enter a letter: ").lower()

            if len(guess) != 1 or not guess.isalpha():
                print("Only a letters allowed.")
                continue
            if guess in guessed_letters:
                print(f"{guess} is already guessed.")
                continue

            guessed_letters.add(guess)

            if guess in answer:
                for i in range(len(answer)):
                    if answer[i] == guess:
                        hint[i] = guess
            else:
                print(f"Incorrect! {guess} is wrong.")
                tries -= 1

            if "_" not in hint:
                display_answer(answer)
                print("You win! Big W!!")
                is_running = False
            elif tries == 0:
                print(f"Sadly, you lost...The word was: {answer}")
                break

def level5():
  global name, ptype
  print()
  print("--------------------------------------")
  print("|   Ingredients        |   Type      |")
  print("--------------------------------------")
  print("| Lucifer Tears        |   Base      |") 
  print("| Octopy Ink           |   Base      |") 
  print("| Berlin Diamond       |   Base      |") 
  print("| God Leaf             |   Base      |")
  print("| Magenta Herb         |   Base      |")
  print("| Stone of Thunder     |   Rare      |")
  print("| Venom Teeth          |   Rare      |") 
  print("| Asgard Stone         |   Rare      |") 
  print("| Thor Tears           |   Rare      |")
  print("--------------------------------------")

  ingredients = { 
    "lucifer tears": "base",
    "octopy ink": "base",
    "berlin diamond": "base",
    "god leaf": "base",
    "magenta herb": "base",
    "stone of thunder": "rare",
    "venom teeth": "rare", 
    "asgard stone": "rare", 
    "thor tears": "rare",
    }

  while True:

      item1 = input("\nEnter first ingredient: ").lower()
      item2 = input("Enter second ingredient: ").lower()

      type1 = ingredients.get(item1)
      type2 = ingredients.get(item2)

      if type1 is None or type2 is None:
          print("Invalid ingredients!")
          continue

      # potion name
      if {item1, item2} == {"lucifer tears", "octopy ink"}:
       name = "Abyssal Shadow Elixir"
      elif {item1, item2} == {"lucifer tears", "berlin diamond"}:
       name = "Fallen Radiance Potion"
      elif {item1, item2} == {"lucifer tears", "god leaf"}:
       name = "Blasphemous Grace Brew"
      elif {item1, item2} == {"lucifer tears", "magenta herb"}:
       name = "Crimson Sin Tonic"
      elif {item1, item2} == {"octopy ink", "berlin diamond"}:
       name = "Midnight Prism Elixir"
      elif {item1, item2} == {"octopy ink", "god leaf"}:
       name = "Sacred Veil Potion"
      elif {item1, item2} == {"octopy ink", "magenta herb"}:
       name = "Inkbound Vital Brew"
      elif {item1, item2} == {"berlin diamond", "god leaf"}:
       name = "Divine Crystal Elixir"
      elif {item1, item2} == {"berlin diamond", "magenta herb"}:
       name = "Rosecut Remedy"
      elif {item1, item2} == {"god leaf", "magenta herb"}:
       name = "Blessed Bloom Potion"
      elif {item1, item2} == {"lucifer tears", "stone of thunder"}:
       name = "Hellstorm Elixir"
      elif {item1, item2} == {"lucifer tears", "venom teeth"}:
       name = "Demonic Fang Serum"
      elif {item1, item2} == {"lucifer tears", "asgard stone"}:
       name = "Fallen Realm Draught"
      elif {item1, item2} == {"lucifer tears", "thor tears"}:
       name = "Judgement of Lightning"
      elif {item1, item2} == {"octopy ink", "stone of thunder"}:
       name = "Stormveil Ink Brew"
      elif {item1, item2} == {"octopy ink", "venom teeth"}:
       name = "Toxic Obscura Elixir"
      elif {item1, item2} == {"octopy ink", "asgard stone"}:
       name = "Runic Shadow Tonic"
      elif {item1, item2} == {"octopy ink", "thor tears"}:
       name = "Thunderblind Draught"
      elif {item1, item2} == {"berlin diamond", "stone of thunder"}:
       name = "Lightning Prism Elixir"
      elif {item1, item2} == {"berlin diamond", "venom teeth"}:
       name = "Venomcut Crystal"
      elif {item1, item2} == {"berlin diamond", "asgard stone"}:
       name = "Realmforge Elixir"
      elif {item1, item2} == {"berlin diamond", "thor tears"}:
       name = "Stormcrown Draught"
      elif {item1, item2} == {"god leaf", "stone of thunder"}:
       name = "Divine Tempest Brew"
      elif {item1, item2} == {"god leaf", "venom teeth"}:
       name = "Corrupted Blessing Elixir"
      elif {item1, item2} == {"god leaf", "asgard stone"}:
       name = "Celestial Root Tonic"
      elif {item1, item2} == {"god leaf", "thor tears"}:
       name = "Thunder Grace Potion"
      elif {item1, item2} == {"magenta herb", "stone of thunder"}:
       name = "Pulseflash Elixir"
      elif {item1, item2} == {"magenta herb", "venom teeth"}:
       name = "Poison Bloom Brew"
      elif {item1, item2} == {"magenta herb", "asgard stone"}:
       name = "Mythic Vital Draught"
      elif {item1, item2} == {"magenta herb", "thor tears"}:
       name = "Scarlet Thunder Tonic"
      elif {item1, item2} == {"stone of thunder", "venom teeth"}:
       name = "Stormfang Elixir"
      elif {item1, item2} == {"stone of thunder", "asgard stone"}:
       name = "Realm of Thunder Draught"
      elif {item1, item2} == {"stone of thunder", "thor tears"}:
       name = "Wrath of the Stormlord"
      elif {item1, item2} == {"venom teeth", "asgard stone"}:
       name = "Cursed Relic Serum"
      elif {item1, item2} == {"venom teeth", "thor tears"}:
       name = "Lightning Venom Elixir"
      elif {item1, item2} == {"asgard stone", "thor tears"}:
       name = "Ascension of Thunder"

      else:
        print("Unknown potion combination!")
        continue

      print(f"Name: {name}")
      with open("list.txt", "a") as f:
        f.write(name + "\n")

      # potion type
      if {type1, type2} == {"base", "base"}:
          ptype = "Healing"
      elif {type1, type2} == {"base", "rare"}:
          ptype = "Attack"
      elif {type1, type2} == {"rare", "rare"}:
          ptype = "Epic"

      print(f"Potion type: {ptype}")
      print()
      break 

def consume_potion():
        global inventory
        inventory = input("Check your potion? (yes/no): ").lower()
        print()
        
        if inventory != "yes":
            print("Your journey will continue.")
            return

        while True:
            with open("list.txt", "r") as f: # Read lines
                lines = f.readlines()

            # Remove empty lines
            if all(line == "\n" for line in lines) or len(lines) == 0:
                print("Your inventory is empty.")
                break

            print("Your inventory:")
            for line in lines:
                if line != "\n":
                    print(line, end="") 

            # wants to consume a potion
            while True:
                use = input("Consume potion? (yes/no): ").lower()
                if use == "yes":
                    break
                elif use == "no":
                    print("You decided not to consume any potion.")
                    return
                else:
                    print("Invalid input. Retry.")

            # which potion to consume
            while True:
                choose = input("Please enter potion full name to consume: ").lower()
                potion = False

                # Rewrite file
                with open("list.txt", "w") as f:
                    for line in lines:
                        if line.strip().lower() == choose and not potion:
                            potion = True  
                        else:
                            f.write(line)  

                if potion:
                    print(f"{choose} has been consumed and removed from your inventory.")
                    break
                else:
                    print("Potion not found in your inventory. Please try again.")
        return inventory

def health_stats():
    global inventory, ptype, updated_numbers1, ptype1, ptype2
    filename = "HealthStats.txt"

    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f) 

    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]

    if inventory == "yes" and ptype1 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype1 != "Healing":
        updated_numbers1 = stats
    elif inventory == "yes" and ptype1 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype1 != "Epic":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype2 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype2 != "Healing":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype2 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype2 != "Epic":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype3 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype3 != "Healing":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype3 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype3 != "Epic":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype4 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype4 != "Healing":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype4 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype4 != "Epic":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype5 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype5 != "Healing":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype5 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype5 != "Epic":
         updated_numbers1 = stats
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers1:
            print(n, file=f)
    return updated_numbers1  

def attack_stats():
    global inventory, ptype, ptype1, ptype2, updated_numbers2
    filename = "AttackStats.txt"

    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f)  

    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]

    if inventory == "yes" and ptype1 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype1 != "Attack":
        updated_numbers2 = stats
    elif inventory == "yes" and ptype1 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype1 != "Epic":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype2 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype2 != "Attack":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype2 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype2 != "Epic":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype3 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype3 != "Attack":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype3 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype3 != "Epic":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype4 == "Healing":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype4 != "Healing":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype4 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype4 != "Epic":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype5 == "Healing":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype5 != "Healing":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype5 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype5 != "Epic":
         updated_numbers2 = stats
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers2:
            print(n, file=f)
    return updated_numbers2

def fight_ghost1():
    filename = "HealthStats.txt"
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]
    updated_numbers1 =[n - 8 for n in stats] 
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers1:
            print(n, file=f)
    return updated_numbers1 

def fight_ghost2():
    filename = "HealthStats.txt"
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]
    updated_numbers2 =[n - 8 for n in stats] 
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers2:
            print(n, file=f)
    return updated_numbers2 

    
def level_5():
  global ptype1, ptype2, ptype3, ptype4, ptype5, updated_numbers1, updated_numbers2
  level5_opening()
  print()
  print('Before we start, lets play a mini game.')
  level5_minigame()
  i = 1
  while i < 5:
    if i == 1:
        print('Create first potion:')
        level5()
        ptype1 = ptype
        consume_potion()
    elif i == 2:
        print('Create second potion:')
        level5()
        ptype2 = ptype
        consume_potion()
    elif i == 3:
        print('Create third potion:')
        level5()
        ptype3 = ptype
        consume_potion()
    elif i == 4:
        print('Create fourth potion:')
        level5()
        ptype4 = ptype
        consume_potion()
    elif i == 4:
        print('Create fifth potion:')
        level5()
        ptype5 = ptype
        consume_potion()
    health_stats()
    attack_stats()
    i += 1
  fight_ghost1()
  fight_ghost2()
  print(f'Player health: {updated_numbers1}')
  print(f'Player attack: {updated_numbers2}')
  filename = "AttackStats.txt"
  stats = []
  with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass
  if updated_numbers1 < 0 or updated_numbers2 < 0:
     print("GAME OVER! ")
     print("byebye...")
  else:
    print('You successfully fought the ghosts!')
    print()
    print('You have now reached the end of this game...')
    print()
    print('might be sad,')
    print('might not be sad because...')
    print()
    print('You obtained the TREASURE CHEST!')
    userinput = input('Press Y to continue').lower()
    if userinput == 'y':
        chest_locked = r"""

        __          _______ _   _ _   _ ______ _____  _ 
        \ \        / /_   _| \ | | \ | |  ____|  __ \| |
         \ \  /\  / /  | | |  \| |  \| | |__  | |__) | |
          \ \/  \/ /   | | | . ` | . ` |  __| |  _  /| |
           \  /\  /   _| |_| |\  | |\  | |____| | \ \|_|
            \/  \/   |_____|_| \_|_| \_|______|_|  \_(_)
                                                        

            \       _________________________       /
                   /                        /|
           __     /                        / |       _
                 /                        /  | 
           __   |________________________/   |       _
                |__________|___|_________|   |
            _   |________________________|   /       __
                |________________________|  /
            /   |________________________| /         \

        """
        print(chest_locked)
        print()
        print("CONGRATULATIONS! The treasure chest is now yours.")
  # check remaining potion/stats

