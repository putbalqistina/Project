import os
player_stats = {"health": 10,
                "attack": 10}
inventory = None
ptype = None

def level4_opening():
    print()
    print("Level 4: Fourth Floor ִֶָ𓂃 ࣪˖𓉸ִֶָྀི ִֶָ་༘࿐")
    print()
    print('OH NO! There are 4 ghosts in front of you!')
    print('It is recommended that you do potions that could help increase your lowest stat.')
    print()

def level4():
  global ptype, name
  print()
  print("--------------------------------------")
  print("|   Ingredients        |   Type      |")
  print("--------------------------------------")
  print("| Blue Krystal         |   Base      |") 
  print("| Meteor Scroll        |   Base      |") 
  print("| Ruby                 |   Base      |") 
  print("| Stone Glory          |   Base      |")
  print("| Yellow Herb          |   Base      |")
  print("| Sirens Tears         |   Rare      |")
  print("| Telang Flower        |   Rare      |") 
  print("| Moon Beer            |   Rare      |") 
  print("| Mermaid Blood        |   Rare      |")
  print("--------------------------------------")

  ingredients = { 
    "blue krystal": "base",
    "meteor scroll": "base",
    "ruby": "base",
    "stone glory": "base",
    "yellow herb": "base",
    "sirens tears": "rare",
    "telang flower": "rare", 
    "moon beer": "rare", 
    "mermaid blood": "rare",
    }

  while True:

      item1 = input("\nEnter first ingredient: ").lower()
      item2 = input("Enter second ingredient: ").lower()

      type1 = ingredients.get(item1)
      type2 = ingredients.get(item2)

      if type1 is None or type2 is None:
          print("Invalid ingredients!")
          continue

      # potion name
      if {item1, item2} == {"blue krystal", "meteor scroll"}:
       name = "Cosmic Resonance Elixir"
      elif {item1, item2} == {"blue krystal", "ruby"}:
       name = "Violet Core Potion"
      elif {item1, item2} == {"blue krystal", "stone glory"}:
       name = "Crystal Bastion Tonic"
      elif {item1, item2} == {"blue krystal", "yellow herb"}:
       name = "Clearwave Remedy"
      elif {item1, item2} == {"meteor scroll", "ruby"}:
       name = "Falling Flame Draught"
      elif {item1, item2} == {"meteor scroll", "stone glory"}:
       name = "Heavenfall Guard Elixir"
      elif {item1, item2} == {"meteor scroll", "yellow herb"}:
       name = "Stardust Recovery Brew"
      elif {item1, item2} == {"ruby", "stone glory"}:
       name = "Emberwall Tonic"
      elif {item1, item2} == {"ruby", "yellow herb"}:
       name = "Vital Flame Potion"
      elif {item1, item2} == {"stone glory", "yellow herb"}:
       name = "Golden Resolve Elixir"
      elif {item1, item2} == {"blue krystal", "sirens tears"}:
       name = "Frozen Lullaby Elixir"
      elif {item1, item2} == {"blue krystal", "telang flower"}:
       name = "Azure Bloom Potion"
      elif {item1, item2} == {"blue krystal", "moon beer"}:
       name = "Lunar Chill Brew"
      elif {item1, item2} == {"blue krystal", "mermaid blood"}:
       name = "Abyssal Crystal Draught"
      elif {item1, item2} == {"meteor scroll", "sirens tears"}:
       name = "Heavenly Dirge Elixir"
      elif {item1, item2} == {"meteor scroll", "telang flower"}:
       name = "Celestial Bloom Brew"
      elif {item1, item2} == {"meteor scroll", "moon beer"}:
       name = "Drunken Comet Draught"
      elif {item1, item2} == {"meteor scroll", "mermaid blood"}:
       name = "Tidal Meteor Elixir"
      elif {item1, item2} == {"ruby", "sirens tears"}:
       name = "Crimson Siren Potion"
      elif {item1, item2} == {"ruby", "telang flower"}:
       name = "Twilight Flame Elixir"
      elif {item1, item2} == {"ruby", "moon beer"}:
       name = "Moonfire Ale"
      elif {item1, item2} == {"ruby", "mermaid blood"}:
       name = "Bloodtide Ember Brew"
      elif {item1, item2} == {"stone glory", "sirens tears"}:
       name = "Sorrowstone Elixir"
      elif {item1, item2} == {"stone glory", "telang flower"}:
       name = "Ancient Bloom Tonic"
      elif {item1, item2} == {"stone glory", "moon beer"}:
       name = "Moonbound Bulwark Brew"
      elif {item1, item2} == {"stone glory", "mermaid blood"}:
       name = "Ocean Bastion Elixir"
      elif {item1, item2} == {"yellow herb", "sirens tears"}:
       name = "Melancholy Cure Potion"
      elif {item1, item2} == {"yellow herb", "telang flower"}:
       name = "Tranquil Blossom Remedy"
      elif {item1, item2} == {"yellow herb", "moon beer"}:
       name = "Sleepwalker’s Draught"
      elif {item1, item2} == {"yellow herb", "mermaid blood"}:
       name = "Tidal Recovery Elixir"
      elif {item1, item2} == {"sirens tears", "telang flower"}:
       name = "Siren’s Dream Elixir"
      elif {item1, item2} == {"sirens tears", "moon beer"}:
       name = "Moonlit Lament Brew"
      elif {item1, item2} == {"sirens tears", "mermaid blood"}:
       name = "Abyssal Siren Serum"
      elif {item1, item2} == {"telang flower", "moon beer"}:
       name = "Lunar Trance Potion"
      elif {item1, item2} == {"telang flower", "mermaid blood"}:
       name = "Ocean Bloom Elixir"
      elif {item1, item2} == {"moon beer", "mermaid blood"}:
       name = "Drunken Tide Ascension"

      else:
        print("Unknown potion combination!")
        continue

      print(f"Name: {name}")
      with open("list.txt", "a") as f:
        f.write(name + "\n")

      # potion type
      if {type1, type2} == {"base", "base"}:
          ptype = "Healing"
      elif {type1, type2} == {"base", "rare"}:
          ptype = "Attack"
      elif {type1, type2} == {"rare", "rare"}:
          ptype = "Epic"

      print(f"Potion type: {ptype}")
      print()
      break 
    
def consume_potion():
        global inventory
        inventory = input("Check your potion? (yes/no): ").lower()
        print()
        
        if inventory != "yes":
            print("Your journey will continue.")
            return

        while True:
            with open("list.txt", "r") as f: # Read lines
                lines = f.readlines()

            # Remove empty lines
            if all(line == "\n" for line in lines) or len(lines) == 0:
                print("Your inventory is empty.")
                break

            print("Your inventory:")
            for line in lines:
                if line != "\n":
                    print(line, end="") 

            # wants to consume a potion
            while True:
                use = input("Consume potion? (yes/no): ").lower()
                if use == "yes":
                    break
                elif use == "no":
                    print("You decided not to consume any potion.")
                    return
                else:
                    print("Invalid input. Retry.")

            # which potion to consume
            while True:
                choose = input("Please enter potion full name to consume: ").lower()
                potion = False

                # Rewrite file
                with open("list.txt", "w") as f:
                    for line in lines:
                        if line.strip().lower() == choose and not potion:
                            potion = True  
                        else:
                            f.write(line)  

                if potion:
                    print(f"{choose} has been consumed and removed from your inventory.")
                    break
                else:
                    print("Potion not found in your inventory. Please try again.")
        return inventory

def level_4_minigame():
    riddles = [
        ("I speak without a mouth and hear without ears. I have nobody, but I come alive with the wind. What am I?",
            "echo"),
        ("I come from a mine and get surrounded by wood always. Everyone uses me. What am I?",
            "pencil lead"),
        ("I have cities, but no houses; forests, but no trees; and water, but no fish. What am I?",
            "map")
    ]

    while True :
        attempts = 2
        passed = True

        for question, answer in riddles :
            correct = False

            while attempts > 0 and not correct :
                print("\n" + question)
                user = input("Your answer: ").lower().strip()

                if user == answer :
                    print("Correct!")
                    correct = True
                else :
                    attempts -= 1
                    print(f"Incorrect! You have {attempts} attempts left.")

            if not correct :
                print("You failed to answer the riddle. Restarting from the beginning.")
                passed = False
                break

        if passed :
            print("You have answered all riddles correctly! The gate opens, and you proceed to the next level.")
            return True
    
def health_stats():
    global inventory, ptype, updated_numbers1, ptype1, ptype2
    filename = "HealthStats.txt"

    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f) 

    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]

    if inventory == "yes" and ptype1 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype1 != "Healing":
        updated_numbers1 = stats
    elif inventory == "yes" and ptype1 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype1 != "Epic":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype2 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype2 != "Healing":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype2 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype2 != "Epic":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype3 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype3 != "Healing":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype3 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype3 != "Epic":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype4 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype4 != "Healing":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype4 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype4 != "Epic":
         updated_numbers1 = stats
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers1:
            print(n, file=f)
    return updated_numbers1  

def attack_stats():
    global inventory, ptype, ptype1, ptype2, updated_numbers2
    filename = "AttackStats.txt"

    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f)  

    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]

    if inventory == "yes" and ptype1 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype1 != "Attack":
        updated_numbers2 = stats
    elif inventory == "yes" and ptype1 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype1 != "Epic":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype2 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype2 != "Attack":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype2 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype2 != "Epic":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype3 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype3 != "Attack":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype3 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype3 != "Epic":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype4 == "Healing":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype4 != "Healing":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype4 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype4 != "Epic":
         updated_numbers2 = stats
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers2:
            print(n, file=f)
    return updated_numbers2

def fight_ghost1():
    filename = "HealthStats.txt"
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]
    updated_numbers1 =[n - 8 for n in stats] 
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers1:
            print(n, file=f)
    return updated_numbers1 

def fight_ghost2():
    filename = "HealthStats.txt"
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]
    updated_numbers2 =[n - 8 for n in stats] 
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers2:
            print(n, file=f)
    return updated_numbers2 


def level_4():
  global ptype1, ptype2, ptype3, ptype4
  level4_opening()
  i = 1
  while i < 5:
    if i == 1:
        print('Create first potion:')
        level4()
        ptype1 = ptype
        consume_potion()
    elif i == 2:
        print('Create second potion:')
        level4()
        ptype2 = ptype
        consume_potion()
    elif i == 3:
        print('Create third potion:')
        level4()
        ptype3 = ptype
        consume_potion()
    else:
        print('Create fourth potion:')
        level4()
        ptype4 = ptype
        consume_potion()
    health_stats()
    attack_stats()
    i += 1
  print('You successfully fought the ghost!')
  fight_ghost1()
  fight_ghost2()
  print(f'Player health: {updated_numbers1}')
  print(f'Player attack: {updated_numbers2}')
  print('Before you proceed to level 5, lets play a minigame.')
  level_4_minigame()
