def starting():
    print ("꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒷꒦꒷꒦꒷꒦꒷꒦꒷꒦꒷꒷꒦꒷꒦꒷")
    print ('Welcome to The Alchemist’s Trial...')
    print ()
    print ('Please make sure that you are fully ready for this adventure {¬ºཀ°}¬')
    readiness = input("Are you ready? (yes/no)").lower()
    print()
    if readiness == "yes":
        print()
        print ("You are a lone adventurer skilled in the art of potion-making. ")
        print()
        print("One night, you arrive at the gates of a long-abandoned castle.")
    else:
        print()
        print ("You coward! You have to be ready.")
        print()
        print ("You will still have to continue play this game, so better be ready by now.")
    print()

    username = input('Before we start, please enter your nickname:')
    print()
    print (f'Hello {username}... (㇏(•̀ᢍ•́)ノ)')
    print ("Please make sure to understand the gameflow, or else... (っ҂ཀ•)っ")
    print("⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘")
    print()
    print("Legends speak of a hidden treasure sealed deep within an abandoned castle. Drawn by curiosity — and greed — you step inside, only to discover that the castle is far from empty.")
    print()
    print("The castle consists of three dangerous floors, each protected by its own obstacles and guardians.")
    print()
    print("To reach the treasure chest at the top, you must survive every floor — using your knowledge of potion-making to overcome what lies ahead.")
    print()
    print("Only those who brew wisely will leave the castle alive.")
    print("⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘⫘")
    print()




    