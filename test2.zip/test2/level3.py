import random
import os
def level3_opening():
    print()
    print("Level 3: Third Floor ִֶָ𓂃 ࣪˖𓉸ִֶָྀི ִֶָ་༘࿐")
    print()
    print('OH NO! There are 3 ghosts in front of you!')
    print('It is recommended that you do potions that could help increase your lowest stat.')
    print('If you pass this minigame, you will get some bonus.')
    print()

def level2():
  while True:
    global ptype
    print()
    print("--------------------------------------")
    print("|   Ingredients        |   Type      |")
    print("--------------------------------------")
    print("|  Red Herb            |   Base      |")
    print("|  Dreamy Flower       |   Base      |")
    print("|  Eye of Orge         |   Base      |")
    print("|  Shadowvine Extract  |   Base      |")
    print("|  Drunkagora          |   Rare      |")
    print("|  Werewolf Blood      |   Rare      |")
    print("|  Fairy Dust          |   Rare      |")
    print("--------------------------------------")

    ingredients = { 
        "red herb": "base",
        "dreamy flower": "base", 
        "eye of orge": "base",
        "shadowvine extract": "base",
        "drunkagora": "rare", 
        "werewolf blood": "rare",
        "fairy dust": "rare"
        }
    if not os.path.exists("list.txt"):
        f = open("list.txt", "x")
        f.close()
    while True:
        item1 = input("\nEnter first ingredient: ").lower()
        item2 = input("Enter second ingredient: ").lower()

        type1 = ingredients.get(item1)
        type2 = ingredients.get(item2)
        if type1 is None or type2 is None:
                print("Invalid ingredients!")
                continue

                # potion name
        if type1 is None or type2 is None:
                print("Invalid ingredients!")
                continue

                # potion name
        if {item1, item2} == {"red herb", "dreamy flower"}:
                name = "Crimson Dream Elixir"
        elif {item1, item2} == {"red herb", "eye of orge"}:
                name = "Orge Vital Tonic"
        elif {item1, item2} == {"red herb", "shadowvine extract"}:
                name = "Shadowroot Brew"
        elif {item1, item2} == {"dreamy flower", "eye of orge"}:
                name = "Lucid Strength Draught"
        elif {item1, item2} == {"dreamy flower", "shadowvine extract"}:
                name = "Mistveil Potion"
        elif {item1, item2} == {"eye of orge", "shadowvine extract"}:
                name = "Dark Brute Elixir"
        elif {item1, item2} == {"red herb", "drunkagora"}:
                name = "Blazing Madness Tonic"
        elif {item1, item2} == {"red herb", "werewolf blood"}:
                name = "Bloodrage Elixir"
        elif {item1, item2} == {"red herb", "fairy dust"}:
                name = "Fae Healing Draught"
        elif {item1, item2} == {"dreamy flower", "drunkagora"}:
                name = "Hallucination Bloom"
        elif {item1, item2} == {"dreamy flower", "werewolf blood"}:
                name = "Moonmind Serum"
        elif {item1, item2} == {"dreamy flower", "fairy dust"}:
                name = "Dreamweaver Potion"
        elif {item1, item2} == {"eye of orge", "drunkagora"}:
                name = "Berserker’s Brew"
        elif {item1, item2} == {"eye of orge", "werewolf blood"}:
                name = "Primal Fury Elixir"
        elif {item1, item2} == {"eye of orge", "fairy dust"}:
                name = "Enchanted Strength Tonic"
        elif {item1, item2} == {"shadowvine extract", "drunkagora"}:
                name = "Night Delirium Draft"
        elif {item1, item2} == {"shadowvine extract", "werewolf blood"}:
                name = "Shadowfang Elixir"
        elif {item1, item2} == {"shadowvine extract", "fairy dust"}:
                name = "Twilight Fae Brew"

        else:
                print("Unknown potion combination!")
                continue

        print(f"Name: {name}")
        with open("list.txt", "a") as f:
          f.write(name + "\n")

                # potion type
        if {type1, type2} == {"base", "base"}:
                ptype = "Healing"
        elif {type1, type2} == {"base", "rare"}:
                ptype = "Attack"

        print(f"Potion type: {ptype}")
        return ptype

def level3():
    global ptype, name
    print() 
    print("--------------------------------------")
    print("|   Ingredients        |   Type      |")
    print("--------------------------------------")
    print("| Kobold Fur           |   Base      |") 
    print("| Fairy Wings          |   Base      |") 
    print("| Witch Heart          |   Base      |") 
    print("| Dragon Fire          |   Base      |")
    print("| Blue Herb            |   Base      |")
    print("| Phoenix Feather      |   Rare      |")
    print("| Stone of Sage        |   Rare      |") 
    print("| Saga                 |   Rare      |") 
    print("| Demons Blood         |   Rare      |")
    print("--------------------------------------")

    ingredients = { 
        "kobold fur": "base",
        "fairy wings": "base", 
        "witch heart": "base",
        "dragon fire": "base",
        "blue herb": "base",
        "phoenix feather": "rare",
        "stone of sage": "rare", 
        "saga": "rare",
        "demons blood": "rare",
        }

    while True:
     
      item1 = input("\nEnter first ingredient: ").lower()
      item2 = input("Enter second ingredient: ").lower()

      type1 = ingredients.get(item1)
      type2 = ingredients.get(item2)

      if type1 is None or type2 is None:
          print("Invalid ingredients!")
          continue

      # potion name
      if {item1, item2} == {"kobold fur", "fairy wings"}:
       name = "Swiftbound Elixir"
      elif {item1, item2} == {"kobold fur", "witch heart"}:
       name = "Hexhide Tonic"
      elif {item1, item2} == {"kobold fur", "dragon fire"}:
       name = "Scorched Hide Brew"
      elif {item1, item2} == {"kobold fur", "blue herb"}:
       name = "Earthskin Remedy"
      elif {item1, item2} == {"fairy wings", "witch heart"}:
       name = "Cursed Flight Draught"
      elif {item1, item2} == {"fairy wings", "dragon fire"}:
       name = "Blazing Skies Elixir"
      elif {item1, item2} == {"fairy wings", "blue herb"}:
       name = "Soothing Wind Potion"
      elif {item1, item2} == {"witch heart", "dragon fire"}:
       name = "Infernal Hex Brew"
      elif {item1, item2} == {"witch heart", "blue herb"}:
       name = "Calming Curse Elixir"
      elif {item1, item2} == {"dragon fire", "blue herb"}:
       name = "Steamflare Tonic"
      elif {item1, item2} == {"kobold fur", "phoenix feather"}:
       name = "Rebirth Hide Elixir"
      elif {item1, item2} == {"kobold fur", "stone of sage"}:
       name = "Ancient Skin Tonic"
      elif {item1, item2} == {"kobold fur", "saga"}:
       name = "Runebound Fur Brew"
      elif {item1, item2} == {"kobold fur", "demons blood"}:
       name = "Hellhide Serum"
      elif {item1, item2} == {"fairy wings", "phoenix feather"}:
       name = "Ascension Flight Potion"
      elif {item1, item2} == {"fairy wings", "stone of sage"}:
       name = "Skybound Wisdom Draught"
      elif {item1, item2} == {"fairy wings", "saga"}:
       name = "Legendwind Elixir"
      elif {item1, item2} == {"fairy wings", "demons blood"}:
       name = "Fallen Angel Brew"
      elif {item1, item2} == {"witch heart", "phoenix feather"}:
       name = "Immortal Curse Elixir"
      elif {item1, item2} == {"witch heart", "stone of sage"}:
       name = "Forbidden Wisdom Brew"
      elif {item1, item2} == {"witch heart", "saga"}:
       name = "Legendary Hex Draught"
      elif {item1, item2} == {"witch heart", "demons blood"}:
       name = "Abyssal Pact Elixir"
      elif {item1, item2} == {"dragon fire", "phoenix feather"}:
       name = "Eternal Flame Elixir"
      elif {item1, item2} == {"dragon fire", "stone of sage"}:
       name = "Runic Inferno Brew"
      elif {item1, item2} == {"dragon fire", "saga"}:
       name = "Mythfire Draught"
      elif {item1, item2} == {"dragon fire", "demons blood"}:
       name = "Hellflame Serum"
      elif {item1, item2} == {"blue herb", "phoenix feather"}:
       name = "Revitalising Rebirth Tonic"
      elif {item1, item2} == {"blue herb", "stone of sage"}:
       name = "Mindclear Elixir"
      elif {item1, item2} == {"blue herb", "saga"}:
       name = "Legendary Remedy"
      elif {item1, item2} == {"blue herb", "demons blood"}:
       name = "Corrupted Healing Brew"
      elif {item1, item2} == {"phoenix feather", "stone of sage"}:
       name = "Elixir of Eternal Insight"
      elif {item1, item2} == {"phoenix feather", "saga"}:
       name = "Legend of Rebirth"
      elif {item1, item2} == {"phoenix feather", "demons blood"}:
       name = "Infernal Resurrection Draught"
      elif {item1, item2} == {"stone of sage", "saga"}:
       name = "Mythic Knowledge Elixir"
      elif {item1, item2} == {"stone of sage", "demons blood"}:
       name = "Forbidden Truth Serum"
      elif {item1, item2} == {"saga", "demons blood"}:
       name = "Demonic Legend Elixir"

      else:
       print("Unknown potion combination!")
       continue

      print(f"Name: {name}")
      with open("list.txt", "a") as f:
        f.write(name + "\n")

      # potion type
      if {type1, type2} == {"base", "base"}:
          ptype = "Healing"
      elif {type1, type2} == {"base", "rare"}:
          ptype = "Attack"
      elif {type1, type2} == {"rare", "rare"}:
          ptype = "Epic"

      print(f"Potion type: {ptype}")
      print()

def consume_potion():
        global inventory
        inventory = input("Check your potion? (yes/no): ").lower()
        print()
        
        if inventory != "yes":
            print("Your journey will continue.")
            return

        while True:
            with open("list.txt", "r") as f: # Read lines
                lines = f.readlines()

            # Remove empty lines
            if all(line == "\n" for line in lines) or len(lines) == 0:
                print("Your inventory is empty.")
                break

            print("Your inventory:")
            for line in lines:
                if line != "\n":
                    print(line, end="") 

            # wants to consume a potion
            while True:
                use = input("Consume potion? (yes/no): ").lower()
                if use == "yes":
                    break
                elif use == "no":
                    print("You decided not to consume any potion.")
                    return
                else:
                    print("Invalid input. Retry.")

            # which potion to consume
            while True:
                choose = input("Please enter potion full name to consume: ").lower()
                potion = False

                # Rewrite file
                with open("list.txt", "w") as f:
                    for line in lines:
                        if line.strip().lower() == choose and not potion:
                            potion = True  
                        else:
                            f.write(line)  

                if potion:
                    print(f"{choose} has been consumed and removed from your inventory.")
                    break
                else:
                    print("Potion not found in your inventory. Please try again.")
        return inventory

def scrambled_game():
    print()
    global unlock, add_attack
    words = {"ghost":"ghsot", "vampire":"vrmapie", "dragon":"dogarn", "goblin":"glbion", "werewolf":"wreewlof"}
    correct_word, scrambled_word = random.choice(list(words.items()))
    print('You will be given a scrambled word.')
    print("Unscramble the word. (Theme: Monster-Creatures)")
    print()
    print (f'Guess this creature {scrambled_word}') 

    guess = input("Enter your guess:").strip().lower()
    if guess == correct_word:
        print()
        print("Well done! You got it correct!")
        print('Guess one more word, and it will lead you to a genie that will add bonus 2 to your Attack!')
        print()
        userchoice = input("Do you want to continue guessing? (yes/no)").lower()
        print()
        if userchoice == 'yes':
            correct_word, scrambled_word = random.choice(list(words.items()))
            print (f'Guess this creature {scrambled_word}')
            guess = input("Enter your guess:").strip().lower()
            print()
            if guess == correct_word:
                print("Perfect! The genie has granted your wish. Attack +2 !")
                add_attack = True
                unlock = True
            else:
                print('You have no retries... sorry.')
                unlock = True
        else:
            print('Oh, you are missing your chance...')
            unlock = True
    else:
        print('Hint: The first and the last letter is in correct position.')
        guess = input("Enter your guess:").strip().lower()
        print()
        if guess == correct_word:
            print("Well done! You got it correct!")
            print("You unlocked the secret ingredient!")
            unlock = True
        else:
            print("Uh oh... you failed to unlock the secret ingredients :(")
            unlock = False
            add_attack = False
    return unlock, add_attack

def health_stats():
    global inventory, ptype, updated_numbers1, ptype1, ptype2
    filename = "HealthStats.txt"

    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f) 

    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]

    if inventory == "yes" and ptype1 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype1 != "Healing":
        updated_numbers1 = stats
    elif inventory == "yes" and ptype1 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype1 != "Epic":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype2 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype2 != "Healing":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype2 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype2 != "Epic":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype3 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype3 != "Healing":
         updated_numbers1 = stats
    elif inventory == "yes" and ptype3 == "Epic":
        updated_numbers1 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype3 != "Epic":
         updated_numbers1 = stats
    else:
         updated_numbers1 = stats
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers1:
            print(n, file=f)
    return updated_numbers1  

def attack_stats():
    global inventory, ptype, ptype1, ptype2, updated_numbers2
    filename = "AttackStats.txt"

    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f)  

    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]

    if inventory == "yes" and ptype1 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype1 != "Attack":
        updated_numbers2 = stats
    elif inventory == "yes" and ptype1 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype1 != "Epic":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype2 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype2 != "Attack":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype2 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype2 != "Epic":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype3 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype3 != "Attack":
         updated_numbers2 = stats
    elif inventory == "yes" and ptype3 == "Epic":
        updated_numbers2 = [n + 1 for n in stats]
    elif inventory == "yes" and ptype3 != "Epic":
         updated_numbers2 = stats
    else:
         updated_numbers2 = stats
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers2:
            print(n, file=f)
    return updated_numbers2

def fight_ghost1():
    filename = "HealthStats.txt"
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]
    updated_numbers1 =[n - 6 for n in stats] 
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers1:
            print(n, file=f)
    return updated_numbers1 

def fight_ghost2():
    filename = "HealthStats.txt"
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]
    updated_numbers2 =[n - 6 for n in stats] 
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers2:
            print(n, file=f)
    return updated_numbers2 

def level_3():
  global unlock, add_attack, ptype1, ptype2, ptype3, updated_numbers1, updated_numbers2
  level3_opening()
  i = 1
  while i < 4:
    unlock = scrambled_game()
    if unlock == (True, True):
        if i == 1:
          print('Create first potion:')
          level3()
          ptype1 = ptype
          print()
          consume_potion()
          print()
        elif i == 2:
          print('Create second potion:')
          level3()
          ptype2 = ptype
          print()
          consume_potion()
          print()
        else:
          print('Create third potion:')
          level3()
          ptype3 = ptype
          print()
          consume_potion()
          print()
    elif unlock == (False, False) and add_attack == False:
        if i == 1:
          print('Create first potion:')
          level2()
          ptype1 = ptype
          print()
          consume_potion()
          print()
        elif i == 2:
          print('Create second potion:')
          level2
          ptype2 = ptype
          print()
          consume_potion()
          print()
        else:
          print('Create third potion:')
          level2()
          ptype3 = ptype
          print()
          consume_potion()
          print()
    health_stats()
    attack_stats()
    i += 1
  print('You successfully fought the ghost!')
  fight_ghost1()
  fight_ghost2()
  print(f'Player health: {updated_numbers1}')
  print(f'Player attack: {updated_numbers2}')