import os


def level1_opening():
    print()
    print("Level 1: First Floor ִֶָ𓂃 ࣪˖𓉸ִֶָྀི ִֶָ་༘࿐")
    print()
    print("The air grows damp and heavy as you step into the lower halls.")
    print()
    print("Something lurks in the shadows, and a wrong move could be fatal.")
    print()
    print('A faceless ghost appears in front of you (but this is a weak one)') 

def level1():
  global ptype
  print("In order to pass this level, you have to create a basic potion using ONLY the BASE ingredients that will be given below:")
  print()
  print("--------------------------------------")
  print("|   Ingredients        |   Type      |")
  print("--------------------------------------")
  print("|  Nightshade Berry    |   Base      |")
  print("|  Moon Dew            |   Base      |")
  print("|  Ashroot             |   Base      |")
  print("|  Dragon Scale Dust   |   Rare      |")
  print("|  Venom Fang          |   Rare      |")
  print("--------------------------------------") 
  print()
  ingredients = { 
  "nightshade berry": "base",
  "moon dew": "base", 
  "ashroot": "base",
  "dragon scale dust": "rare", 
  "venom fang": "rare" 
  }

  if not os.path.exists("list.txt"):
    f = open("list.txt", "x")
    f.close()
  
  while True:

    item1 = input("\nEnter first ingredient: ").lower()
    item2 = input("Enter second ingredient: ").lower()

    type1 = ingredients.get(item1)
    type2 = ingredients.get(item2)

    if type1 is None or type2 is None:
     print("Invalid ingredients!")
     continue

  # potion name
    if {item1, item2} == {"nightshade berry", "dragon scale dust"}:
     name = "Drakeshadow Toxin"
    elif {item1, item2} == {"nightshade berry", "venom fang"}:
     name = "Assassin’s Bloom"
    elif {item1, item2} == {"nightshade berry", "moon dew"}:
     name = "Lunar Venom Elixir"
    elif {item1, item2} == {"nightshade berry", "ashroot"}:
     name = "Elixir of Withering Shadows"
    elif {item1, item2} == {"moon dew", "ashroot"}:
     name = "Mist of Ancient Roots"
    elif {item1, item2} == {"moon dew", "dragon scale dust"}:
     name = "Celestial Scale Draught"
    elif {item1, item2} == {"moon dew", "venom fang"}:
     name = "Moonbite Serum"
    elif {item1, item2} == {"ashroot", "dragon scale dust"}:
     name = "Emberhide Tonic"
    elif {item1, item2} == {"ashroot", "venom fang"}:
     name = "Gravefang Brew"

    else:
     print("Unknown potion combination!")
     continue

    print(f"Name: {name}")
    with open("list.txt", "a") as f:
          f.write(name + "\n")

  # potion type
    if {type1, type2} == {"base", "base"}:
        ptype = "Healing"
        return ptype
    elif {type1, type2} == {"base", "rare"}:
        ptype = "Attack"
        return ptype

    print(f"Potion type: {ptype}")
    print()
    break  

def consume_potion():
        global inventory
        inventory = input("Check your potion? (yes/no): ").lower()
        print()
        
        if inventory != "yes":
            print("Your journey will continue.")
            return

        while True:
            with open("list.txt", "r") as f: # Read lines
                lines = f.readlines()

            # Remove empty lines
            if all(line == "\n" for line in lines) or len(lines) == 0:
                print("Your inventory is empty.")
                break

            print("Your inventory:")
            for line in lines:
                if line != "\n":
                    print(line, end="") 

            # wants to consume a potion
            while True:
                use = input("Consume potion? (yes/no): ").lower()
                if use == "yes":
                    break
                elif use == "no":
                    print("You decided not to consume any potion.")
                    return
                else:
                    print("Invalid input. Retry.")

            # which potion to consume
            while True:
                choose = input("Please enter potion full name to consume: ").lower()
                potion = False

                # Rewrite file
                with open("list.txt", "w") as f:
                    for line in lines:
                        if line.strip().lower() == choose and not potion:
                            potion = True  
                        else:
                            f.write(line)  

                if potion:
                    print(f"{choose} has been consumed and removed from your inventory.")
                    break
                else:
                    print("Potion not found in your inventory. Please try again.")
        return inventory
    
import os

def health_stats():
    global inventory, ptype, updated_numbers1
    filename = "HealthStats.txt"

    # Ensure the file exists with the initial value 10  
    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f)  # write "10\n"

    # Read the current health value(s) from file (treat file as one integer per line)
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  # ignore any bad lines

    # If file was empty or invalid, fall back to [10]
    if not stats:
        stats = [10]

    # Decide the updated value(s)
    if inventory == "yes" and ptype == "Healing":
        # Increase by +2 (you can change the rule if needed)
        updated_numbers1 = [n + 2 for n in stats]
    else:
        # Keep health stats at the initial value (10)
        updated_numbers1 = [10]

    # Write the result back to the file (one integer per line)
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers1:
            print(n, file=f)
    return updated_numbers1  # optional, useful for testing

def attack_stats():
    global inventory, ptype, updated_numbers2
    filename = "AttackStats.txt"

    # Ensure the file exists with the initial value 10
    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f)  # write "10\n"

    # Read the current health value(s) from file (treat file as one integer per line)
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  # ignore any bad lines

    # If file was empty or invalid, fall back to [10]
    if not stats:
        stats = [10]

    # Decide the updated value(s)
    if inventory == "yes" and ptype == "Attack":
        # Increase by +2 (you can change the rule if needed)
        updated_numbers2 = [n + 2 for n in stats]
    else:
        # Keep health stats at the initial value (10)
        updated_numbers2 = [10]

    # Write the result back to the file (one integer per line)
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers2:
            print(n, file=f)
    return updated_numbers2  # optional, useful for testing


def level_1():
   level1_opening()
   level1()
   consume_potion()
   print('You successfully fought the ghost!')
   health_stats()
   attack_stats()
   print(f'Player health: {updated_numbers1}')
   print(f'Player attack: {updated_numbers2}')


   
   

    
        
    