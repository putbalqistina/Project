# *************************************************************************
# Course: CSP1114 PROBLEM SOLVING AND PROGRAM DESIGN
# Lecture / Lab Section: TC1L / TL4L
# Trimester: 2530
# Group Name (from eBwise): Group 7
# Names: PUTERI BALQIS QISTINA BINTI MD IZAN | AMINAH BINTI MAZLAN | NURDANIA QISTINA BINTI NOOR AZIZUL RAHIM
# IDs: 252FC253ME | 252FC253CF | 252FC253H4
# *************************************************************************

import opening
import level1
import level2
import level3
import level4
import level5


#opening story
opening.starting()

# level 1
level1.level_1()

userchoice = input("Press Y to continue.").lower()
if userchoice == 'y':
    # level 2
    level2.level_2()

userchoice = input("Press Y to continue.").lower()
if userchoice == 'y':
    # level 3
    level3.level_3()

userchoice = input("Press Y to continue.").lower()
if userchoice == 'y':
    # level 4
    level4.level_4()

userchoice = input("Press Y to continue.").lower()
if userchoice == 'y':
    # level 5
    level5.level_5()





