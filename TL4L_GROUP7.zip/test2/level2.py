import os

# level 2 opening
def level2_opening():
    print()
    print("Level 2: Second Floor ִֶָ𓂃 ࣪˖𓉸ִֶָྀི ִֶָ་༘࿐")
    print()
    print('OH NO! There are 2 ghosts in front of you!')
    print('You have to create 2 potions in this round.')
    print()

# potion logic      
def level2():
  while True:
    global ptype
    print()
    print("--------------------------------------")
    print("|   Ingredients        |   Type      |")
    print("--------------------------------------")
    print("|  Red Herb            |   Base      |")
    print("|  Dreamy Flower       |   Base      |")
    print("|  Eye of Orge         |   Base      |")
    print("|  Shadowvine Extract  |   Base      |")
    print("|  Drunkagora          |   Rare      |")
    print("|  Werewolf Blood      |   Rare      |")
    print("|  Fairy Dust          |   Rare      |")
    print("--------------------------------------")

    ingredients = { 
        "red herb": "base",
        "dreamy flower": "base", 
        "eye of orge": "base",
        "shadowvine extract": "base",
        "drunkagora": "rare", 
        "werewolf blood": "rare",
        "fairy dust": "rare"
        }
    if not os.path.exists("list.txt"):
        f = open("list.txt", "x")
        f.close()
    while True:
        item1 = input("\nEnter first ingredient: ").lower()
        item2 = input("Enter second ingredient: ").lower()

        type1 = ingredients.get(item1)
        type2 = ingredients.get(item2)
        if type1 is None or type2 is None:
                print("Invalid ingredients!")
                continue

                # potion name
        if type1 is None or type2 is None:
                print("Invalid ingredients!")
                continue

                # potion name
        if {item1, item2} == {"red herb", "dreamy flower"}:
                name = "Crimson Dream Elixir"
        elif {item1, item2} == {"red herb", "eye of orge"}:
                name = "Orge Vital Tonic"
        elif {item1, item2} == {"red herb", "shadowvine extract"}:
                name = "Shadowroot Brew"
        elif {item1, item2} == {"dreamy flower", "eye of orge"}:
                name = "Lucid Strength Draught"
        elif {item1, item2} == {"dreamy flower", "shadowvine extract"}:
                name = "Mistveil Potion"
        elif {item1, item2} == {"eye of orge", "shadowvine extract"}:
                name = "Dark Brute Elixir"
        elif {item1, item2} == {"red herb", "drunkagora"}:
                name = "Blazing Madness Tonic"
        elif {item1, item2} == {"red herb", "werewolf blood"}:
                name = "Bloodrage Elixir"
        elif {item1, item2} == {"red herb", "fairy dust"}:
                name = "Fae Healing Draught"
        elif {item1, item2} == {"dreamy flower", "drunkagora"}:
                name = "Hallucination Bloom"
        elif {item1, item2} == {"dreamy flower", "werewolf blood"}:
                name = "Moonmind Serum"
        elif {item1, item2} == {"dreamy flower", "fairy dust"}:
                name = "Dreamweaver Potion"
        elif {item1, item2} == {"eye of orge", "drunkagora"}:
                name = "Berserker’s Brew"
        elif {item1, item2} == {"eye of orge", "werewolf blood"}:
                name = "Primal Fury Elixir"
        elif {item1, item2} == {"eye of orge", "fairy dust"}:
                name = "Enchanted Strength Tonic"
        elif {item1, item2} == {"shadowvine extract", "drunkagora"}:
                name = "Night Delirium Draft"
        elif {item1, item2} == {"shadowvine extract", "werewolf blood"}:
                name = "Shadowfang Elixir"
        elif {item1, item2} == {"shadowvine extract", "fairy dust"}:
                name = "Twilight Fae Brew"

        else:
                print("Unknown potion combination!")
                continue

        print(f"Name: {name}")
        with open("list.txt", "a") as f:
          f.write(name + "\n")

                # potion type
        if {type1, type2} == {"base", "base"}:
                ptype = "Healing"
        elif {type1, type2} == {"base", "rare"}:
                ptype = "Attack"

        print(f"Potion type: {ptype}")
        return ptype

# consume potion   
def consume_potion():
        global inventory
        inventory = input("Check your potion? (yes/no): ").lower()
        print()
        
        if inventory != "yes":
            print("Your journey will continue.")
            return

        while True:
            with open("list.txt", "r") as f: # Read lines
                lines = f.readlines()

            # Remove empty lines
            if all(line == "\n" for line in lines) or len(lines) == 0:
                print("Your inventory is empty.")
                break

            print("Your inventory:")
            for line in lines:
                if line != "\n":
                    print(line, end="") 

            # wants to consume a potion
            while True:
                use = input("Consume potion? (yes/no): ").lower()
                if use == "yes":
                    break
                elif use == "no":
                    print("You decided not to consume any potion.")
                    return
                else:
                    print("Invalid input. Retry.")

            # which potion to consume
            while True:
                choose = input("Please enter potion full name to consume: ").lower()
                potion = False

                # Rewrite file
                with open("list.txt", "w") as f:
                    for line in lines:
                        if line.strip().lower() == choose and not potion:
                            potion = True  
                        else:
                            f.write(line)  

                if potion:
                    print(f"{choose} has been consumed and removed from your inventory.")
                    break
                else:
                    print("Potion not found in your inventory. Please try again.")
        return inventory

# player health stats
def health_stats():
    global inventory, ptype, updated_numbers1, ptype1, ptype2
    filename = "HealthStats.txt"

    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f) 

    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]

    if inventory == "yes" and ptype1 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype1 != "Healing":
        updated_numbers1 = stats
    elif inventory == "yes" and ptype2 == "Healing":
        updated_numbers1 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype2 != "Healing":
         updated_numbers1 = stats
    else:
         updated_numbers1 = stats
    
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers1:
            print(n, file=f)
    return updated_numbers1  

# stats after fight ghost
def fight_ghost1():
    filename = "HealthStats.txt"
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]
    updated_numbers1 =[n - 2 for n in stats] 
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers1:
            print(n, file=f)
    return updated_numbers1 

def fight_ghost2():
    filename = "HealthStats.txt"
    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]
    updated_numbers2 =[n - 2 for n in stats] 
    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers2:
            print(n, file=f)
    return updated_numbers2 

# player attack stats
def attack_stats():
    global inventory, ptype, ptype1, ptype2, updated_numbers2
    filename = "AttackStats.txt"

    if not os.path.exists(filename):
        with open(filename, "w", encoding="utf-8") as f:
            print(10, file=f)  

    stats = []
    with open(filename, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    stats.append(int(line))
                except ValueError:
                    pass  

    if not stats:
        stats = [10]

    if inventory == "yes" and ptype1 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype1 != "Attack":
        updated_numbers2 = stats
    elif inventory == "yes" and ptype2 == "Attack":
        updated_numbers2 = [n + 2 for n in stats]
    elif inventory == "yes" and ptype2 != "Attack":
         updated_numbers2 = stats
    else:
         updated_numbers2 = stats

    with open(filename, "w", encoding="utf-8") as f:
        for n in updated_numbers2:
            print(n, file=f)
    return updated_numbers2  

#level 2 function
def level_2():
   global ptype1, ptype2, ptype, updated_numbers1, updated_numbers2 
   level2_opening()
   print("Don't choose both rare ingredients!")
   i = 1
   while i < 3:
    if i == 1:
         print('Create first potion:')
         level2()
         ptype1 = ptype
         print()
         consume_potion()
         print()
    else:
         print('Create second potion:')
         level2()
         ptype2 = ptype
         print()
         consume_potion()
         print()
    health_stats()
    attack_stats()
    i += 1
   print('You successfully fought the ghost!')
   fight_ghost1()
   fight_ghost2()
   print(f'Player health: {updated_numbers1}')
   print(f'Player attack: {updated_numbers2}')
   

